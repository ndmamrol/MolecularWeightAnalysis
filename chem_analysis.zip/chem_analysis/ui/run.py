from chem_analysis.app import app

if __name__ == '__main__':
    app.run_server(debug=True)
